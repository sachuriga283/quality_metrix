from tkinter import Button
from phy.apps.template import template_gui,load_model
from phy.gui import Actions
import os


self = template_gui('S:/Sachuriga/Ephys_Recording/CR_CA1/65410/65410_2023-11-25_13-57-58_A_phy_k_manual/params.py')
