from setuptools import setup, find_packages

setup(
    name='nwb4fprobe',
    version='0.1.0',
    url='https://github.com/sachuriga283/quality_metrix.git',
    author='sachuriga283',
    author_email='sachuriga.sachuriga@ntnu.no',
    description='Description of my package',
    packages=find_packages(),    
    install_requires=[],
)