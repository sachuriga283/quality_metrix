#Recalculating the quality matrix and downsampling the LFP signal
